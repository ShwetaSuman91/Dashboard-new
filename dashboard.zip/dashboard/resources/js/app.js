    
require('./bootstrap.js');
require('./lightbox-plus-jquery.min.js'); 
require('./script.js');