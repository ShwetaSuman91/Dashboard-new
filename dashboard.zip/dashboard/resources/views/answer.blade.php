<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-AU">

<head>
  <title>Vregan</title>
  <meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- <link rel="stylesheet" type="text/css" href="gila-screen.css" media="screen" title="Gila (screen)" /> -->
  <!-- <link rel="stylesheet" type="text/css" href="gila-print.css" media="print" /> -->




  <style>
    body {
      color: black;
      background-color: white;
      font-family: "times new roman", times, roman, serif;
      font-size: 12pt;
      margin: 0;
      padding: 0;
    }

    acronym,
    .titleTip {
      font-style: italic;
      border-bottom: none;
    }

    acronym:after,
    .titleTip:after {
      /* Prints titles after the acronyms/titletips */
      content: "("attr(title) ")";
      font-size: 90%;
      font-style: normal;
      padding-left: 1ex;
    }

    .doNotPrint {
      display: none !important;
    }


    /* ##### Header ##### */

    #header {
      margin: 0;
      padding: 0;
      border-bottom: 1px solid black;
    }

    .headerTitle {
      font-size: 200%;
      margin: 0;
      padding: 0 0 0.5ex 0;
    }

    .headerTitle a {
      color: black;
      background-color: transparent;
      font-family: "trebuchet ms", verdana, helvetica, arial, sans-serif;
      font-weight: normal;
      text-decoration: none;
    }

    .subHeader {
      display: none;
    }


    /* ##### Side Bars ##### */

    #side-bar {
      display: none;
    }


    /* ##### Main Copy ##### */

    #main-copy {
      text-align: justify;
      margin: 0;
      padding: 0;
    }

    #main-copy h1 {
      font-family: "trebuchet ms", verdana, helvetica, arial, sans-serif;
      font-size: 120%;
      margin: 2ex 0 1ex 0;
      padding: 0;
    }

    #main-copy a {
      color: black;
      background-color: transparent;
      text-decoration: none;
    }

    #main-copy a:after {
      content: "<"attr(href) ">";
      font-size: 90%;
      padding-left: 1ex;
    }

    p {
      margin: 0 0 2ex 0;
      padding: 0;
    }

    dl {
      margin: 0;
      padding: 0;
    }

    dt {
      font-weight: bold;
      margin: 0;
      padding: 0 0 1ex 0;
    }

    dd {
      margin: 0 0 2ex 1.5em;
      padding: 0;
    }


    /* ##### Footer ##### */

    /* #footer {
  margin: 2em 0 0 0;
  padding: 1ex 0 0 0;
  border-top: 1px solid black;
}

#footer a {
  color: black;
  background-color: transparent;
  text-decoration: none;
} */


    /*  */
    body {
      color: black;
      /* background-color: rgb(243,242,235); */
      background-color: #eeeeee;
      font-family: verdana, helvetica, arial, sans-serif;
      font-size: 73%;
      /* Enables font size scaling  */
      margin: 0;
      padding: 0;
    }

    html>body {
      font-size: 9pt;
    }

    acronym,
    .titleTip {
      border-bottom: 1px dotted rgb(168, 140, 83);
      cursor: help;
      margin: 0;
      padding: 0;
    }

    .doNotDisplay {
      display: none !important;
    }


    .smallCaps {
      font-size: 117%;
      font-variant: small-caps;
    }


    /* ##### Header ##### */

    #header {
      color: inherit;
      background-color: rgb(184, 38, 25);
    }

    .headerTitle {
      margin: 0;
      padding: 0.25em 4mm 0.25em 4mm;
    }

    .headerTitle a {
      color: black;
      background-color: transparent;
      text-decoration: none;
      font-size: 110%;
      font-weight: bold;
      font-style: italic;
    }

    .headerTitle>a {
      font-size: 138%;
    }

    .headerTitle span {
      color: white;
      background-color: transparent;
      font-weight: normal;
    }

    .subHeader {
      color: white;
      background-color: black;
      font-size: 109%;
      text-align: center;
      margin: 0;
      padding: 0.5ex 0;
    }

    .subHeader a {
      color: white;
      background-color: black;
      text-decoration: none;
      font-weight: bold;
      margin: 0;
      padding: 0 1ex;
    }

    .subHeader a:hover {
      color: black;
      background-color: white;
    }


    /* ##### Left Side Bar ##### */

    .leftSideBar {
      width: 12.5em;
      float: left;
      clear: left;
    }

    .leftSideBar .sideBarTitle {
      color: rgb(64, 64, 64);
      background-color: rgb(230, 223, 207);
      font-weight: bold;
      margin: 0;
      padding: 0.8ex 1ex;
    }

    .leftSideBar ul {
      list-style-type: none;
      list-style-position: outside;
      margin: 0 0 1em 0;
      padding: 0;
    }

    .leftSideBar li {
      margin: 1ex;
      padding: 0 0 1.25ex 0.75ex;
    }

    .leftSideBar a {
      color: rgb(166, 140, 83);
      background-color: transparent;
      text-decoration: none;
    }

    .leftSideBar a:hover {
      color: rgb(64, 64, 64);
      background-color: transparent;
      text-decoration: none;
    }

    .leftSideBar .sideBarText {
      color: rgb(166, 140, 83);
      background-color: transparent;
      line-height: 1.25em;
      margin: 1ex 0.25ex 1.5em 0.75ex;
      padding: 0;
      display: block;
    }

    .leftSideBar .sideBarText a {
      text-decoration: underline;
    }

    .leftSideBar .sideBarText a:hover {
      text-decoration: none;
    }

    .leftSideBar .thisPage {
      color: rgb(64, 64, 64);
      background-color: transparent;
      font-weight: bold;
    }


    /* ##### Right Side Bar ##### */

    .rightSideBar {
      width: 13em;
      margin: 2ex 0.75ex 0 0;
      padding: 0;
      float: right;
      clear: right;
      border: 1px solid rgb(216, 210, 195);
    }

    [class~="rightSideBar"] {
      margin-right: 1.5ex;
    }

    .rightSideBar .sideBarTitle {
      color: black;
      background-color: rgb(230, 223, 207);
      font-weight: bold;
      margin: 1.25ex 1ex;
      padding: 0.9ex 1ex;
    }

    .rightSideBar a {
      color: rgb(166, 140, 83);
      background-color: transparent;
      text-decoration: underline;
      font-weight: bold;
    }

    .rightSideBar a:hover {
      text-decoration: none;
    }

    .rightSideBar .sideBarText {
      line-height: 1.5em;
      margin: 0;
      padding: 0 2ex 1em 2ex;
    }

    .rightSideBar .more {
      text-decoration: none;
      text-align: right;
      margin: 0;
      padding: 0 2ex 1em 2ex;
      display: block;
    }

    .rightSideBar .more:hover {
      text-decoration: underline;
    }


    /* ##### Main Copy ##### */

    #main-copy {
      color: black;
      background-color: white;
      text-align: justify;
      line-height: 1.5em;
      margin: 0 0 0 12.5em;
      padding: 0.5ex 15em 1em 1em;
      border-left: 1px solid rgb(216, 210, 195);
    }

    #main-copy h1 {
      color: rgb(166, 140, 83);
      background-color: transparent;
      font-family: arial, verdana, helvetica, sans-serif;
      font-size: 175%;
      font-weight: bold;
      font-style: italic;
      text-align: left;
      margin: 1em 0 0 0;
      padding: 1em 0 0 0;
      border-top: 1px solid rgb(216, 210, 195);
    }

    #main-copy a {
      color: rgb(168, 140, 83);
      background-color: transparent;
      text-decoration: underline;
    }

    #main-copy a:hover {
      text-decoration: none;
    }

    p {
      margin: 1em 0 1.5em 0;
      padding: 0;
    }

    dt {
      font-weight: bold;
      margin: 0;
      padding: 0 0 0.5ex 0;
    }

    dd {
      margin: 0 0 1.5em 1.5em;
      padding: 0;
    }

    /* navbar */
    .navbar {
      color: black;
      background: #3AC47D !important;
      padding: 5px 20px;
      border-radius: 0;
      border: none;
      box-shadow: 0 0 4px rgba(0, 0, 0, .1);
    }

    .navbar img {
      border-radius: 50%;
      width: 36px;
      height: 36px;
      margin-right: 10px;
    }

    .navbar .navbar-brand img {
      height: 60px;
      width: 70px;
    }

    .search-box {
      position: relative;

    }

    .search-box input {
      padding-right: 35px;
      min-height: 38px;
      border: none;
      background: #faf7fd;
      border-radius: 20px !important;
    }

    .search-box input:focus {
      background: #fff;
      box-shadow: none;
    }

    .search-box .input-group-addon {
      min-width: 35px;
      border: none;
      background: transparent;
      position: absolute;
      right: 0;
      z-index: 9;
      padding: 10px 7px;
      height: 100%;
    }

    .search-box i {
      color: #a0a5b1;
      font-size: 19px;
    }

    .navbar .nav-item i {
      font-size: 18px;
    }

    .navbar .nav-item span {
      position: relative;
      top: 3px;
    }

    .navbar .navbar-nav>a {
      color: #000000B3;
      padding: 8px 15px;
      font-size: 14px;
    }

    .navbar .navbar-nav>a:hover,
    .navbar .navbar-nav>a:focus {
      color: black;
      text-shadow: 0 0 4px rgba(255, 255, 255, 0.3);
    }

    .navbar .navbar-nav>a>i {
      display: block;
      text-align: center;
    }

    .navbar .dropdown-item i {
      font-size: 16px;
      min-width: 22px;
    }

    .navbar .dropdown-item .material-icons {
      font-size: 21px;
      line-height: 16px;
      vertical-align: middle;
      margin-top: -2px;
    }

    .navbar .nav-item.open>a,
    .navbar .nav-item.open>a:hover,
    .navbar .nav-item.open>a:focus {
      color: black;
      background: none !important;
    }

    .navbar .dropdown-menu {
      border-radius: 1px;
      border-color: #e5e5e5;
      box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
    }

    .navbar .dropdown-menu a {
      color: #777 !important;
      padding: 8px 20px;
      line-height: normal;
      font-size: 15px;
    }

    .navbar .dropdown-menu a:hover,
    .navbar .dropdown-menu a:focus {
      color: #333 !important;
      background: transparent !important;
    }

    .navbar .navbar-nav .active a,
    .navbar .navbar-nav .active a:hover,
    .navbar .navbar-nav .active a:focus {
      color: black;
      text-shadow: 0 0 4px rgba(255, 255, 255, 0.2);
      background: transparent !important;
    }

    .navbar .navbar-nav .user-action {
      padding: 9px 15px;
      font-size: 15px;
    }

    .navbar .navbar-toggle {
      border-color: #fff;
    }

    .navbar .navbar-toggle .icon-bar {
      background: #fff;
    }

    .navbar .navbar-toggle:focus,
    .navbar .navbar-toggle:hover {
      background: transparent;
    }

    .navbar .navbar-nav .open .dropdown-menu {
      background: #faf7fd;
      border-radius: 1px;
      border-color: #faf7fd;
      box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
    }

    .navbar .divider {
      background-color: #e9ecef !important;
    }

    @media (min-width: 1200px) {
      .form-inline .input-group {
        width: 350px;
        margin-left: 30px;
      }
    }

    @media (max-width: 1199px) {
      .navbar .navbar-nav>a>i {
        display: inline-block;
        text-align: left;
        min-width: 30px;
        position: relative;
        top: 4px;
      }

      .navbar .navbar-collapse {
        border: none;
        box-shadow: none;
        padding: 0;
      }

      .navbar .navbar-form {
        border: none;
        display: block;
        margin: 10px 0;
        padding: 0;
      }

      .navbar .navbar-nav {
        margin: 8px 0;
      }

      .navbar .navbar-toggle {
        margin-right: 0;
      }

      .input-group {
        width: 100%;
      }

    }

    .vl {
      border-left: 1px solid;
      height: 500px;
    }

    .h7 {
      font-size: 0.8rem;
    }

    .gedf-wrapper {
      margin-top: 0.97rem;
    }

    @media (min-width: 992px) {
      .gedf-main {
        padding-left: 4rem;
        padding-right: 4rem;
      }

      .gedf-card {
        margin-bottom: 2.77rem;
      }
    }

    /**Reset Bootstrap*/
    .dropdown-toggle::after {
      content: none;
      display: none;
    }



    input[type=text],
    select,
    textarea {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      resize: vertical;
    }

    label {
      padding: 12px 12px 12px 0;
      display: inline-block;
    }

    input[type=submit] {
      background-color: #04AA6D;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      float: right;
    }

    input[type=submit]:hover {
      background-color: #047da1;
    }

    .container {
      border-radius: 90px;
      background-color: #fdfcfc;
      padding: 50px;
    }

    .col-25 {
      float: left;
      width: 25%;
      margin-top: 6px;
    }

    .col-75 {
      float: left;
      width: 100%;
      margin-top: 6px;
      height: 200%;
    }


    .row:after {
      content: "";
      display: table;
      clear: both;
    }


    @media screen and (max-width: 600px) {

      .col-25,
      .col-75,
      input[type=submit] {
        width: 100%;
        margin-top: 0;
      }
    }

    .search {
      float: right;

    }

    .modal-header,
    h4,
    .close {
      background-color: #5cb85c;
      color: white !important;
      text-align: center;
      font-size: 30px;
    }

    .modal-footer {
      background-color: #f9f9f9;
    }

    .modal-backdrop {
      /* z-index: -1; */
      display: none;

    }
    @media only screen {
      
    }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body>

  <nav class="navbar navbar-expand-xl navbar-dark bg-dark sticky-top">
    <a href="#" class="navbar-brand">
      <img src="https://github.com/Shubhamlmp/vragen/blob/main/mForumlogo.png?raw==true" alt="">
    </a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
      <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Collection of nav links, forms, and other content for toggling -->
    <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
      <form class="navbar-form form-inline">
        <div class="input-group search-box">
          <input type="text" id="search" class="form-control" placeholder="Search M-Forum...">
          <span class="input-group-addon"><i class="material-icons">&#xE8B6;</i></span>
        </div>
      </form>
      <div class="navbar-nav ml-auto">
        <a href="/" class="nav-item "><i class="fa fa-home"></i><span>Home</span></a>
        <a href="answer" class="nav-item "><i class="fa fa-pencil"></i><span>Answer</span></a>
     
        <!-- <li><a href="" data-toggle="modal" data-target="#exampleModalCenter"> <span
                class="nav-item nav-link"><i class="fa fa-help"></i><span>Add Question</span></a></li> -->
        <a href="" data-toggle="modal" data-target="#exampleModalCenter" class="nav-item "><i class="fa fa-pie-chart"></i><span>Add Question</span></a>


        <a href="#" class="nav-item "><i class="fa fa-sign-out"></i><span>Logout</span></a>

        <div class="nav-item dropdown">
          <a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQA3W3oppN7sdVCsUWwwnPIn9pX6E6G2UW70w&usqp=CAU " class="avatar" alt="Avatar">User Profile<b class="caret"></b></a>





          <div class="dropdown-menu">
            <a href="#" class="dropdown-item"><i class="fa fa-user"></i> Profile</a>
            <a href="#" class="dropdown-item"><i class="fa fa-sliders"></i>Setting</a>
            <a href="#" class="dropdown-item"><i class="fa fa-moon-o" aria-hidden="true"></i>Dark mode</a>
            <div class="divider dropdown-divider"></div>
            <a href="#" class="dropdown-item"><i class="material-icons">&#xE8AC;</i> Logout</a>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- ##### Left Sidebar ##### -->
  <div class="leftSideBar">
    <p class="sideBarTitle">categories</p>
    <ul>
      <li><a href="#">Technology</a></li>
      <li><a href="#cross-browser">friction</a></li>
      <li><a href="#stylesheets">Stylesheets</a></li>
      <li><a href="#accessibility">Accessibility</a></li>
    </ul>

    <ul>
      <li><a href="#">cricket</a></li>
      <li><a href="#">Designs</a></li>
      <li><a href="#">Logos</a></li>

    </ul>
    <p class="sideBarTitle">Comments</p>
    <span class="sideBarText"> Comments and constructive criticisms are welcome <a href="#">via email</a>. </span>
  </div>


  <!-- ##### Right Sidebar ##### -->
  <div class="rightSideBar">



    <p class="sideBarTitle">News</p>
    <div class="sideBarText"><strong>? May 03</strong><br />
      Submitted revised version oF MET GALA <a href="#">open to read full news</a></div>
    <div class="sideBarText"><strong>3 Feb 03</strong><br />
      Delhi: 1,094 new Covid cases, two fatalities; +ve rate up. </div>
    <a href="" class="more">more news &raquo;</a>
    <p class="sideBarTitle">hot topics</p>
    <div class="sideBarText"><strong>Ipl</strong><br />
      <a href="#">info</a>&nbsp;|&nbsp;<a href="#">crickbuzz</a>
    </div>
    <div class="sideBarText"><strong>Upsc</strong><br />
      <a href="#">About</a>&nbsp;|&nbsp;<a href="#">view website</a>
    </div>
    <div class="sideBarText"><strong>Product Foxtrot</strong><br />
      <a href="#">info</a>&nbsp;|&nbsp;<a href="#">download</a>
    </div>
    {{-- <p class="sideBarTitle">Validation</p>
    <div class="sideBarText">Validate the <a href="http://validator.w3.org/check/referer">XHTML</a> and <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> of this page.</div> --}}
  </div>
  </div>


  </div>










  <div class="back-drop">
    <div class="modal fade" style=" position:fixed;" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">

          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle"> ADD QUESTION</h5>
            <button type="button" style="outline: none;" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <form class="modal-form" action="{{ url('/') }}/data" name="myForm" onsubmit="return validateForm()" method="post">
              @csrf
              <div class="form-group">
                <div class="form-group">

                  <div class="col-form-label">
                    <label for="message-text">Category</label>
                  </div>

                  <div class="col-75">
                    <select id="require" name="category">
                      <option value="">select your Category</option>

                      <option name=" ">Technology</option>
                      <option name=" ">Defence</option>
                      <option name=" ">Indian History</option>
                      <option name=" ">Sports</option>
                      <option name=" ">Education</option>

                    </select>
                  </div>
                  <div style="color:red;" id="error"></div>


                </div>


                <div class="form-group" id="xyz">
                  <label for="message-text" class="col-form-label">Add Question:</label>
                  <textarea class="form-control" name="des" placeholder="Start your Question with ' What ',' How ',' Why ' ect." id="desc"></textarea>
                  <div style="color:red;" id="err"></div>

                </div>


                <div class="modal-footer">
                  <button type="button" id="dismissModelBtn" class="btn btn-danger" data-dismiss="modal">Close</button>

                  <button type="submit" class="btn btn-success">Submit</button>
                </div>

              </div>
            </form>

          </div>
        </div>
      </div>
    </div>


  </div>



  <script type="text/javascript">
    $(document).ready(function() {

      let template = null;
      $('.modal').on('show.bs.modal', function(event) {
        template = $(this).html();
      });

      $('.modal').on('hidden.bs.modal', function(e) {
        $(this).html(template);
      }); 
    });
  </script>

  <script>
    function validateForm() {
      document.getElementById("error").innerHTML = "";
      document.getElementById("err").innerHTML = "";
      let x = document.forms["myForm"]["require"].value;
      let y = document.forms["myForm"]["desc"].value;


      if (x == '') {
        document.getElementById("error").innerHTML = "Field is required";
        return false;
      } else if (y == '') {
        document.getElementById("err").innerHTML = "Field is required";

        return false;
      } else {

        return true;

      }

    }
  </script>
  <!-- <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> -->
  <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->
  <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->
  <!-- <script language="JavaScript" type="text/javascript" src="/js/jquery-1.2.6.min.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/jquery-ui-personalized-1.5.2.packed.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/sprinkle.js"></script> -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


</body>

</html>
