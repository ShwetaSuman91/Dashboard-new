<!DOCTYPE html>
<html lang="en">
<head>
  <title>vragen</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
crossorigin="anonymous"></script>


<style>
    @import  url('https://fonts.googleapis.com/css?family=Open+Sans&display=swap');
body {
	font-family: 'Open Sans', sans-serif;
  background: #e9e7e7;
}
nav{

	position: relative;
	/* margin: 270px auto 0; */
	width: 100%;
	height: 50px;
	background: #ffffff;
	/* border-radius: 8px; */
	font-size: 0;
	box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);
}
nav a{

	font-size: 15px;
	text-transform: uppercase;
	color: white;
	text-decoration: none;
	line-height: 50px;
	position: relative;
	z-index: 1;
	display: inline-block;
	text-align: center;
}
nav .animation{
	position: absolute;
	height: 100%;
	/* height: 5px; */
	top: 0;
	/* bottom: 0; */
	z-index: 0;
	background: #1abc9c;
	border-radius: 8px;
	transition: all .5s ease 0s;
}
nav a:nth-child(1){
	width: 100px;
}
nav .start-home, a:nth-child(1):hover~.animation{
	width: 100px;
	left: 0;
}
nav a:nth-child(2){
	width: 110px;
}
nav a:nth-child(2):hover~.animation{
	width: 110px;
	left: 100px;
}
nav a:nth-child(3){
	width: 100px;
}
nav a:nth-child(3):hover~.animation{
	width: 100px;
	left: 210px;
}
nav a:nth-child(4){
	width: 160px;
}
nav a:nth-child(4):hover~.animation{
	width: 160px;
	left: 310px;
}
nav a:nth-child(5){
	width: 120px;
}
nav a:nth-child(5):hover~.animation{
	width: 120px;
	left: 470px;
}




</style>
</head>
<body>






    <nav>
      <a href="#">Home</a>
      <a href="#">About</a>
      <a href="#">Blog</a>
      <a href="#">Portfolio</a>
      <a href="#">Contact</a>
      <div class="animation start-home"></div>
    </nav>




<div class="container" >
  <div class="row">
      <div class="col-md-4">
          <div class="card">
              
              <ul class="list-group list-group-flush">
                  <li class="list-group-item">
                      <div class="h6 ">TECHNOLOGY</div>
                  </li>
                  <li class="list-group-item">
                      <div class="h6">COOKING</div>
                  </li>
                  <li class="list-group-item">MUSIC</li>
                  <li class="list-group-item">ALL ABOUT CRICKET</li>
                  <li class="list-group-item">BOOKS</li>
                  <li class="list-group-item">VISTING AND TRAVELS</li>
              </ul>
          </div>
      </div>

      <div class="container bootdey">
        <div class="col-md-6 bootstrap snippets">
        <div class="panel">
          <div class="panel-body">
           <p style="border: 2px">What do you want to ask or share </p>

            <div class="mar-top clearfix">
              <button class="btn btn-sm btn-primary pull-right" type="submit"><i class="fa fa-pencil fa-fw"></i> Share</button>
              <a class="btn btn-trans btn-icon " href="#"><b>Ask</b></a>
              <a class="btn btn-trans btn-icon fa fa-pen add-pen" href="#"><b>Answer</b></a>
            </div>
          </div>
        </div>

</body>
</html>










































<?php /**PATH /home/me/dashboard/resources/views/dash.blade.php ENDPATH**/ ?>