<!DOCTYPE html>
<html lang="en">
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    

<style>
    .nav-container{
    width: 110px;
    height: 230px;
    background-color: rgb(48, 162, 255);
    border: solid 2px none;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
}

#navbar{
    position: relative;
    margin: auto;
 }

.link-container {
    margin: 10px;
    font-size: 18px;
    width: 100%;
    color: white;
}

.nav-link{
    display:inline-block;
}

</style>
    
</head>
<body>


  
    
    <div class="nav-container">
        <nav id = 'navbar'>
    
            <div class="link-container ">
                <a href='#' class="nav-link">Home</a>
            </div>
    
            <div class="link-container">
                <a href='#' class="nav-link">FAQ</a>
            </div>
            <div class="link-container">
                <a href='#' class="nav-link">List a Coin</a>
            </div>
    
            <div class="link-container">
                <a href='#' class="nav-link">Contact Us</a>
            </div>
        </nav>
    </div>
    
    <script>
    var hovering = function(){
        $("nav").show("slide", { direction: "right" }, 1000);
     };
     
     var leaving = function(){
        $("nav").hide("slide", { direction: "left" }, 1000);
     };
     </script>
     


</body>
</html><?php /**PATH /home/me/dashboard/resources/views/nav.blade.php ENDPATH**/ ?>