
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Vregan</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>
body {
	background: #eeeeee;
	font-family: 'Varela Round', sans-serif;
}
.navbar {
	color: #fff;
	background: #9d2121 !important;
	padding: 5px 20px;
	border-radius: 0;
	border: none;
	box-shadow: 0 0 4px rgba(0,0,0,.1);
}
.navbar img {
	border-radius: 50%;
	width: 36px;
	height: 36px;
	margin-right: 10px;
}
.navbar .navbar-brand {
	color: #efe5ff;
	padding-left: 0;
	padding-right: 50px;
	font-size: 24px;		
}
.navbar .navbar-brand:hover, .navbar .navbar-brand:focus {
	color: #fff;
}
.navbar .navbar-brand i {
	font-size: 25px;
	margin-right: 5px;
}
.search-box {
	position: relative;
}	
.search-box input {
	padding-right: 35px;
	min-height: 38px;
	border: none;
	background: #faf7fd;
	border-radius: 3px !important;
}
.search-box input:focus {		
	background: #fff;
	box-shadow: none;
}
.search-box .input-group-addon {
	min-width: 35px;
	border: none;
	background: transparent;
	position: absolute;
	right: 0;
	z-index: 9;
	padding: 10px 7px;
	height: 100%;
}
.search-box i {
	color: #a0a5b1;
	font-size: 19px;
}
.navbar .nav-item i {
	font-size: 18px;
}
.navbar .nav-item span {
	position: relative;
	top: 3px;
}
.navbar .navbar-nav > a {
	color: #efe5ff;
	padding: 8px 15px;
	font-size: 14px;		
}
.navbar .navbar-nav > a:hover, .navbar .navbar-nav > a:focus {
	color: #fff;
	text-shadow: 0 0 4px rgba(255,255,255,0.3);
}
.navbar .navbar-nav > a > i {
	display: block;
	text-align: center;
}
.navbar .dropdown-item i {
	font-size: 16px;
	min-width: 22px;
}
.navbar .dropdown-item .material-icons {
	font-size: 21px;
	line-height: 16px;
	vertical-align: middle;
	margin-top: -2px;
}
.navbar .nav-item.open > a, .navbar .nav-item.open > a:hover, .navbar .nav-item.open > a:focus {
	color: #fff;
	background: none !important;
}
.navbar .dropdown-menu {
	border-radius: 1px;
	border-color: #e5e5e5;
	box-shadow: 0 2px 8px rgba(0,0,0,.05);
}
.navbar .dropdown-menu a {
	color: #777 !important;
	padding: 8px 20px;
	line-height: normal;
	font-size: 15px;
}
.navbar .dropdown-menu a:hover, .navbar .dropdown-menu a:focus {
	color: #333 !important;
	background: transparent !important;
}
.navbar .navbar-nav .active a, .navbar .navbar-nav .active a:hover, .navbar .navbar-nav .active a:focus {
	color: #fff;
	text-shadow: 0 0 4px rgba(255,255,255,0.2);
	background: transparent !important;
}
.navbar .navbar-nav .user-action {
	padding: 9px 15px;
	font-size: 15px;
}
.navbar .navbar-toggle {
	border-color: #fff;
}
.navbar .navbar-toggle .icon-bar {
	background: #fff;
}
.navbar .navbar-toggle:focus, .navbar .navbar-toggle:hover {
	background: transparent;
}
.navbar .navbar-nav .open .dropdown-menu {
	background: #faf7fd;
	border-radius: 1px;
	border-color: #faf7fd;
	box-shadow: 0 2px 8px rgba(0,0,0,.05);
}
.navbar .divider {
	background-color: #e9ecef !important;
}
@media (min-width: 1200px){
	.form-inline .input-group {
		width: 350px;
		margin-left: 30px;
	}
}
@media (max-width: 1199px){
	.navbar .navbar-nav > a > i {
		display: inline-block;			
		text-align: left;
		min-width: 30px;
		position: relative;
		top: 4px;
	}
	.navbar .navbar-collapse {
		border: none;
		box-shadow: none;
		padding: 0;
	}
	.navbar .navbar-form {
		border: none;			
		display: block;
		margin: 10px 0;
		padding: 0;
	}
	.navbar .navbar-nav {
		margin: 8px 0;
	}
	.navbar .navbar-toggle {
		margin-right: 0;
	}
	.input-group {
		width: 100%;
	}

}
.vl {
  border-left: 1px solid ;
  height:500px ;
}
.h7 {
    font-size: 0.8rem;
}

.gedf-wrapper {
    margin-top: 0.97rem;
}

@media (min-width: 992px) {
    .gedf-main {
        padding-left: 4rem;
        padding-right: 4rem;
    }
    .gedf-card {
        margin-bottom: 2.77rem;
    }
}

/**Reset Bootstrap*/
.dropdown-toggle::after {
    content: none;
    display: none;
}

/* 
.modal {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 0;
    visibility: hidden;
    transform: scale(1.1);
    transition: visibility 0s linear 0.25s, opacity 0.25s 0s, transform 0.25s;
}

.modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 1rem 1.5rem;
    width: 24rem;
    border-radius: 0.5rem;
}

.close-button {
    float: right;
    width: 1.5rem;
    line-height: 1.5rem;
    text-align: center;
    cursor: pointer;
    border-radius: 0.25rem;
    background-color: lightgray;
}

.close-button:hover {
    background-color: darkgray;
}

.show-modal {
    opacity: 1;
    visibility: visible;
    transform: scale(1.0);
    transition: visibility 0s linear 0s, opacity 0.25s 0s, transform 0.25s;
} */


.leftSideBar {
  width: 12.5em;
  float: left;
  clear: left;
}

.leftSideBar .sideBarTitle {
  color: rgb(64,64,64);
  background-color: rgb(230,223,207);
  font-weight: bold;
  margin: 0;
  padding: 0.8ex 1ex;
}

.leftSideBar ul {
  list-style-type: none;
  list-style-position: outside;
  margin: 0 0 1em 0;
  padding: 0;
}

.leftSideBar li {
  margin: 1ex;
  padding: 0 0 1.25ex 0.75ex;
}

.leftSideBar a {
  color: rgb(166,140,83);
  background-color: transparent;
  text-decoration: none;
}

.leftSideBar a:hover {
  color: rgb(64,64,64);
  background-color: transparent;
  text-decoration: none;
}

.leftSideBar .sideBarText {
  color: rgb(166,140,83);
  background-color: transparent;
  line-height: 1.25em;
  margin: 1ex 0.25ex 1.5em 0.75ex;
  padding: 0;
  display: block;
}

.leftSideBar .sideBarText a {
  text-decoration: underline;
}

.leftSideBar .sideBarText a:hover {
  text-decoration: none;
}

.leftSideBar .thisPage {
  color: rgb(64,64,64);
  background-color: transparent;
  font-weight: bold;
}


/* ##### Right Side Bar ##### */

.rightSideBar {
  width: 13em;
  margin: 2ex 0.75ex 0 0;
  padding: 0;
  float: right;
  clear: right;
  border: 1px solid rgb(216,210,195);
}

[class~="rightSideBar"] {
  margin-right: 1.5ex;
}

.rightSideBar .sideBarTitle {
  color: black;
  background-color: rgb(230,223,207);
  font-weight: bold;
  margin: 1.25ex 1ex;
  padding: 0.9ex 1ex;
}

.rightSideBar a {
  color: rgb(166,140,83);
  background-color: transparent;
  text-decoration: underline;
  font-weight: bold;
}

.rightSideBar a:hover {
  text-decoration: none;
}

.rightSideBar .sideBarText {
  line-height: 1.5em;
  margin: 0;
  padding: 0 2ex 1em 2ex;
}

.rightSideBar .more {
  text-decoration: none;
  text-align: right;
  margin: 0;
  padding: 0 2ex 1em 2ex;
  display: block;
}

.rightSideBar .more:hover {
  text-decoration: underline;
}


body {
  color: black;
  background-color: white;
  font-family: "times new roman", times, roman, serif;
  font-size: 12pt;
  margin: 0;
  padding: 0;
}

acronym, .titleTip {
  font-style: italic;
  border-bottom: none;
}

acronym:after, .titleTip:after {  /* Prints titles after the acronyms/titletips. Doesn't work in MSIE */
  content: "(" attr(title) ")";
  font-size: 90%;
  font-style: normal;
  padding-left: 1ex;
}

.doNotPrint {
  display: none !important;
}


/* ##### Header ##### */

#header {
  margin: 0;
  padding: 0;
  border-bottom: 1px solid black;
}

.headerTitle {
  font-size: 200%;
  margin: 0;
  padding: 0 0 0.5ex 0;
}

.headerTitle a {
  color: black;
  background-color: transparent;
  font-family: "trebuchet ms", verdana, helvetica, arial, sans-serif;
  font-weight: normal;
  text-decoration: none;
}

.subHeader {
  display: none;
}


/* ##### Side Bars ##### */

#side-bar {
  display: none;
}


/* ##### Main Copy ##### */

#main-copy {
  text-align: justify;
  margin: 0;
  padding: 0;
}

#main-copy h1 {
  font-family: "trebuchet ms", verdana, helvetica, arial, sans-serif;
  font-size: 120%;
  margin: 2ex 0 1ex 0;
  padding: 0;
}

#main-copy a {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

#main-copy a:after {  /* Prints the links' URIs after the links' texts. Doesn't work in MSIE */
  content: "<" attr(href) ">";
  font-size: 90%;
  padding-left: 1ex;
}

p {
  margin: 0 0 2ex 0;
  padding: 0;
}

dl {
  margin: 0;
  padding: 0;
}

dt {
  font-weight: bold;
  margin: 0;
  padding: 0 0 1ex 0;
}

dd {
  margin: 0 0 2ex 1.5em;
  padding: 0;
}


/* ##### Footer ##### */

#footer {
  margin: 2em 0 0 0;
  padding: 1ex 0 0 0;
  border-top: 1px solid black;
}

#footer a {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

/**********************************
 * TITLE: Gila Screen Stylesheet  * 
 * URI  : gila/gila-screen.css    *
 * MODIF: 2003-Apr-30 19:09 +0800 *
 **********************************/


/* ##### Common Styles ##### */

body {
  color: black;
  background-color: rgb(243,242,235);
  font-family: verdana, helvetica, arial, sans-serif;
  font-size: 73%;  /* Enables font size scaling in MSIE */
  margin: 0;
  padding: 0;
}

html > body {
  font-size: 9pt;
}

acronym, .titleTip {
  border-bottom: 1px dotted rgb(168,140,83);
  cursor: help;
  margin: 0;
  padding: 0;
}

.doNotDisplay {
  display: none !important;
}


.smallCaps {
  font-size: 117%;
  font-variant: small-caps;
}


/* ##### Header ##### */

#header {
  color: inherit;
  background-color: rgb(184,38,25);
}

.headerTitle {
  margin: 0;
  padding: 0.25em 4mm 0.25em 4mm;
}

.headerTitle a {
  color: black;
  background-color: transparent;
  text-decoration: none;
  font-size: 110%;  /* For MSIE */
  font-weight: bold;
  font-style: italic;
}

.headerTitle > a {
  font-size: 138%;  /* For fully standards-compliant user agents */
}

.headerTitle span {
  color: white;
  background-color: transparent;
  font-weight: normal;
}

.subHeader {
  color: white;
  background-color: black;
  font-size: 109%;
  text-align: center;
  margin: 0;
  padding: 0.5ex 0;
}

.subHeader a {
  color: white;
  background-color: black;
  text-decoration: none;
  font-weight: bold;
  margin: 0;
  padding: 0 1ex;
}

.subHeader a:hover {
  color: black;
  background-color: white;
}


/* ##### Left Side Bar ##### */

.leftSideBar {
  width: 12.5em;
  float: left;
  clear: left;
}

.leftSideBar .sideBarTitle {
  color: rgb(64,64,64);
  background-color: rgb(230,223,207);
  font-weight: bold;
  margin: 0;
  padding: 0.8ex 1ex;
}

.leftSideBar ul {
  list-style-type: none;
  list-style-position: outside;
  margin: 0 0 1em 0;
  padding: 0;
}

.leftSideBar li {
  margin: 1ex;
  padding: 0 0 1.25ex 0.75ex;
}

.leftSideBar a {
  color: rgb(166,140,83);
  background-color: transparent;
  text-decoration: none;
}

.leftSideBar a:hover {
  color: rgb(64,64,64);
  background-color: transparent;
  text-decoration: none;
}

.leftSideBar .sideBarText {
  color: rgb(166,140,83);
  background-color: transparent;
  line-height: 1.25em;
  margin: 1ex 0.25ex 1.5em 0.75ex;
  padding: 0;
  display: block;
}

.leftSideBar .sideBarText a {
  text-decoration: underline;
}

.leftSideBar .sideBarText a:hover {
  text-decoration: none;
}

.leftSideBar .thisPage {
  color: rgb(64,64,64);
  background-color: transparent;
  font-weight: bold;
}


/* ##### Right Side Bar ##### */

.rightSideBar {
  width: 13em;
  margin: 2ex 0.75ex 0 0;
  padding: 0;
  float: right;
  clear: right;
  border: 1px solid rgb(216,210,195);
}

[class~="rightSideBar"] {
  margin-right: 1.5ex;
}

.rightSideBar .sideBarTitle {
  color: black;
  background-color: rgb(230,223,207);
  font-weight: bold;
  margin: 1.25ex 1ex;
  padding: 0.9ex 1ex;
}

.rightSideBar a {
  color: rgb(166,140,83);
  background-color: transparent;
  text-decoration: underline;
  font-weight: bold;
}

.rightSideBar a:hover {
  text-decoration: none;
}

.rightSideBar .sideBarText {
  line-height: 1.5em;
  margin: 0;
  padding: 0 2ex 1em 2ex;
}

.rightSideBar .more {
  text-decoration: none;
  text-align: right;
  margin: 0;
  padding: 0 2ex 1em 2ex;
  display: block;
}

.rightSideBar .more:hover {
  text-decoration: underline;
}


/* ##### Main Copy ##### */

#main-copy {
  color: black;
  background-color: white;
  text-align: justify;
  line-height: 1.5em;
  margin: 0 0 0 12.5em;
  padding: 0.5ex 15em 1em 1em;
  border-left: 1px solid rgb(216,210,195);
}

#main-copy h1 {
  color: rgb(166,140,83);
  background-color: transparent;
  font-family: arial, verdana, helvetica, sans-serif;
  font-size: 175%;
  font-weight: bold;
  font-style: italic;
  text-align: left;
  margin: 1em 0 0 0;
  padding: 1em 0 0 0;
  border-top: 1px solid rgb(216,210,195);
}

#main-copy a {
  color: rgb(168,140,83);
  background-color: transparent;
  text-decoration: underline;
}

#main-copy a:hover {
  text-decoration: none;
}

p {
  margin: 1em 0 1.5em 0;
  padding: 0;
}

dt {
  font-weight: bold;
  margin: 0;
  padding: 0 0 0.5ex 0;
}

dd {
  margin: 0 0 1.5em 1.5em;
  padding: 0;
}


/* ##### Footer ##### */

#footer {
  color: black;
  background-color: rgb(230,223,207);
  font-size: 92%;
  text-align: center;
  line-height: 1.25em;
  margin: 0;
  padding: 1em 4mm 1em 4mm;
  clear: both;
}

#footer div {
  margin: 0;
  padding: 0 0 1ex 0;
}

#footer a {
  color: black;
  background-color: transparent;
  text-decoration: underline;
  font-weight: bold;
}

#footer a:hover {
  text-decoration: none;
}



</style>
</head> 
<body>
<nav class="navbar navbar-expand-xl navbar-dark bg-dark sticky-top">
	<a href="#" class="navbar-brand"><i class="fa fa-cube"></i>Vragen<b></b></a>  		
	<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
		<span class="navbar-toggler-icon"></span>
	</button>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">		
		<form class="navbar-form form-inline">
			<div class="input-group search-box">								
				<input type="text" id="search" class="form-control" placeholder="Search Vragen...">
				<span class="input-group-addon"><i class="material-icons">&#xE8B6;</i></span>
			</div>
		</form>
		<div class="navbar-nav ml-auto">
			<a href="#" class="nav-item nav-link active"><i class="fa fa-home"></i><span>Home</span></a>
			<a href="#" class="nav-item nav-link"><i class="fa fa-pencil"></i><span>Answer</span></a>
			
			<a href="#" class="nav-item nav-link"><i class="fa fa-pie-chart"></i><span>Add Question</span></a>
			<a href="#" class="nav-item nav-link"><i class="fa fa-briefcase"></i><span>Careers</span></a>
            <a href="#" class="nav-item nav-link"><i class="fa fa-sign-in"></i><span>Login</span></a>

			<div class="nav-item dropdown">
				<a href="#" data-toggle="dropdown" class="nav-item nav-link dropdown-toggle user-action"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQA3W3oppN7sdVCsUWwwnPIn9pX6E6G2UW70w&usqp=CAU " class="avatar" alt="Avatar">User Profile<b class="caret"></b></a>
				<div class="dropdown-menu">
					<a href="#" class="dropdown-item"><i class="fa fa-user-o"></i> Profile</a>
					<a href="#" class="dropdown-item"><i class="fa fa-sliders"></i>Setting</a>
					<a href="#" class="dropdown-item"><i class="fa fa-moon-o" aria-hidden="true"></i>Dark mode</a>
                    <a href="#" class="dropdown-item"><i class="fa fa-sign-out"></i>Logout</a>
					<div class="divider dropdown-divider"></div>
					<a href="#" class="dropdown-item"><i class="material-icons">&#xE8AC;</i> Logout</a>
				</div>
			</div>
		</div>
	</div>
</nav>



	



	  
		



			







<div class="leftSideBar">
    <p class="sideBarTitle">Categories</p>
    <ul>
      <li><a href="#">Science</a></li>
      <li><a href="#cross-browser">cooking</a></li>
      <li><a href="#stylesheets">Sreading</a></li>
      <li><a href="#accessibility">funding</a></li>
    
      <li><a href="#">memes</a></li>
      <li><a href="#">teams</a></li>
      <li><a href="#">behaviour</a></li>
	  <li><a href="#">behaviour</a></li>
	  <li><a href="#">behaviour</a></li>
    </ul>


	

	<div class="rightSideBar">
		<p class="sideBarTitle">News</p>
		<div class="sideBarText"><strong>? May 03</strong><br />
		  Submitted revised version of Gila to <a href="#">OSWD</a></div>
		<div class="sideBarText"><strong>3 Feb 03</strong><br />
		  Original version of Gila submitted</div>
		<a href="" class="more">more news &raquo;</a>
		<p class="sideBarTitle">Downloads</p>
		<div class="sideBarText"><strong>Product Delta</strong><br />
		  <a href="#">info</a>&nbsp;|&nbsp;<a href="#">download</a></div>
		<div class="sideBarText"><strong>Product Echo</strong><br />
		  <a href="#">info</a>&nbsp;|&nbsp;<a href="#">download</a></div>
		<div class="sideBarText"><strong>Product Foxtrot</strong><br />
		  <a href="#">info</a>&nbsp;|&nbsp;<a href="#">download</a></div>
		<p class="sideBarTitle">Validation</p>
		<div class="sideBarText">Validate the <a href="http://validator.w3.org/check/referer">XHTML</a> and <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> of this page.</div>
	  </div>
	</div>


</body>
</html>	
</html><?php /**PATH /home/me/dashboard/resources/views/dashb.blade.php ENDPATH**/ ?>